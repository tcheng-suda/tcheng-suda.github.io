[191]&nbsp; <span style="color:blue;"> Efficient Circularly Polarized Luminescence and Bright White Emission from Hybrid Indium-based Perovskites via Achiral Building Blocks  </span>  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Du LP; Zhou QW; He QQ; Liu Y; Lv HJ; Shen YQ; Sheng LL; **Cheng T**; Yang H; Fang Y&#42;; Ning WH&#42;; Chi LF&#42;;   
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Submitted **2023**  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  
[190]&nbsp; <span style="color:blue;"> Conversion mechanism of sulfur in room-temperature sodium-sulfur battery with carbonate-based electrolyte  </span>  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Jin F; Wang B&#42;; Wang RJ; Liu Y; Zhang N; Bao CY; Wang DL&#42;; **Cheng T&#42;**; Liu HK; Dou SX&#42;;   
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Submitted **2023**  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  
[186]&nbsp; <span style="color:blue;"> Air-stable Na3.5C6O6 as a sodium compensation additive in cathode of Na-ion batteries  </span>  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Cao MY; Xu L; Guo YJ; Li YX; Fang Q; Liu Y; Bai R; Zhu JC; Li XY; Gao YR&#42;; Cheng T; Hu YS; Wang XF&#42;; Guo YG; Wang ZX&#42;; Chen LQ;   
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Submitted **2023**  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  
[185]&nbsp; <span style="color:blue;"> Acetonitrile-based Local High-Concentration Electrolytes for Advanced Lithium Metal Batteries  </span>  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Li MH; Liu Y; Yang XM&#42;; Zhang Q; Cheng YF; Zhou QW; **Cheng T&#42;**; Gu M&#42;;   
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Submitted **2023**  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  
[184]&nbsp; <span style="color:blue;"> Boosting the acidic water oxidation activity by an interfacial oxygen migration in rutile-1T-heterophase IrO2 catalysts  </span>  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Zhu WX; Sun QT; Ma MJ; Liao F&#42;; Shao Q; Huang H; Feng K; Qin KY; Shi J; Yu H; Gao DD; Chen JX; Yang H; Yu PP; Zhong J; **Cheng T&#42;**; Shao MW&#42;; Liu Y&#42;; Kang ZH&#42;;   
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Submitted **2023**  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  
[183]&nbsp; <span style="color:blue;"> Stable Cycling of Lithium Metal Batteries Enabled by Lean-Oxygen Ether- Based Electrolyte  </span>  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Li XP; Liu Y; Guo YZ; He ZX; Chen YW; Zhang YC; Jie YL; Li WX; **Cheng T&#42;**; Cao RG&#42;; Jiao SH&#42;;   
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Submitted **2023**  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  
[182]&nbsp; <span style="color:blue;"> Interfacial Polymerization Mechanisms Assisted Flame Retardancy Process of a Low-Flammable Electrolytes on Lithium Anode  </span>  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Ma BY; Liu Y&#42;; Sun QT; Yang H; Xie M; **Cheng T&#42;**;   
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Submitted **2023**  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  
[181]&nbsp; <span style="color:blue;"> Physical Inspired Machine Learning Prediction of Battery Coulombic Efficiency Leveraging Small Datasets  </span>  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Sun QT; Feng S; Jie YL; Liu Y; Ma BY; Wu JY; Zhang JY; Jiao SH; Cao RG; **Cheng T&#42;**;   
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Submitted **2023**  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  
[180]&nbsp; <span style="color:blue;"> Nitrogen contained Rhodium Nanosheet Catalysts for Efficient Hydrazine Oxidation Reaction  </span>  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Shi J; Sun QT; Chen JX; Zhu WX; Cheng T; Ma MJ; Fan ZL&#42;; Yang H&#42;; Liao F&#42;; Shao MW&#42;; Kang ZH&#42;;   
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Appl. Catal. B **2024**, 343, 123561  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;[https://doi.org/10.1016/j.apcatb.2023.123561](https://doi.org/10.1016/j.apcatb.2023.123561)  
  
[179]&nbsp; <span style="color:blue;"> Urea Synthesis via Electrocatalytic Oxidative Coupling of CO with NH3 on Pt  </span>  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Xiong HC; Yu PP; cheng Tao; Xu BJ; Lu Q;   
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Submitted **2023**  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  
[178]&nbsp; <span style="color:blue;"> In situ Imaging of the Atomic Phase Transition Dynamics in Metal Halide Perovskites  </span>  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Ma MM; Zhang XL; Chen X; Xiong H; Xu L; **Cheng T**; Yuan JY; Wei F; Shen BY&#42;;   
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Nat. Commun. **2023**, ASAP  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;[https://doi.org/10.1038/s41467-023-42999-5](https://doi.org/10.1038/s41467-023-42999-5)  
  
[177]&nbsp; <span style="color:blue;"> A Holistic Additive Protocol Steers Dendrite-Free Zn(101) Orientational Electrodeposition  </span>  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Su YW; Xu L; Sun YJ; Guo WY; Yang XZ; Zou YH; Ding M; Zhang QH; Qiao CP; Dou SX; **Cheng T&#42;**; Sun JY&#42;;   
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Small **2023**, ASAP  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  
[176]&nbsp; <span style="color:blue;"> Fast Interfacial Defluorination Kinetics Enables Stable Cycling of Low-Temperature Lithium Metal Batteries  </span>  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Li XP; Li MH; Liu Y; Jie YL; Li WX; Chen YW; Huang FY; Zhang YC; **Cheng T&#42;**; Gu M&#42;; Jiao SH&#42;; Cao RG&#42;;   
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Submitted **2023**  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  
[175]&nbsp; <span style="color:blue;"> Layered Quasi-Nevskite Metastable-Phase Cobalt Oxide: A New Structure Accelerating Alkaline Oxygen Evolution Reaction  </span>  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Fan ZL; Sun QT; Yang H; Zhu WX; Liao F; Shao Q; Zhang TY; Huang H; **Cheng T**; Shao MH&#42;; Liu Y&#42;; Shao MW&#42;; Kang ZH&#42;;   
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Submitted **2023**  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  
[174]&nbsp; <span style="color:blue;"> Understanding steric hindrance effect of solvent molecule in localized high-concentration electrolyte for lithium metal batteries  </span>  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Li XP; Pan YX; Liu Y; Jie YL; Chen SQ; Wang SY; He ZX; Ren XD; **Cheng T&#42;**; Cao RG&#42;; Jiao SH&#42;;   
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Carbon Neutrality **2023**, ASAP  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;[http://dx.doi.org/10.1007/s43979-023-00074-4](http://dx.doi.org/10.1007/s43979-023-00074-4)  
  
[173]&nbsp; <span style="color:blue;"> Superiority of real-space imaging for discovering an unexpected asymmetric structure in metal organic framework  </span>  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Feng Jl; Feng ZP; Xu L; Meng HB; Chen X&#42;; Ma MM; Wang L; Wei F&#42;; **Cheng T&#42;**; Shen BY&#42;;   
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Submitted **2023**  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  
[172]&nbsp; <span style="color:blue;"> Unraveling the Solvent Effect on Solid-Electrolyte Interphase Formation for Sodium Metal Batteries  </span>  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Wang SY; Weng ST; Li XP; Liu Y; Huang XL; Jie YL; Pan YX; Zhou HM; Wang XF; Li Q; **Cheng T&#42;**; Cao RG&#42;; Jiao SH&#42;; Xu DS&#42;;   
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Angew. Chem. Int. Ed. **2023**  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;[https://doi.org/10.1002/anie.202313447](https://doi.org/10.1002/anie.202313447)  
  
[171]&nbsp; <span style="color:blue;"> Artificial intelligence for the understanding of electrolyte chemistry and electrode interface in lithium battery  </span>  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Chen YW; Liu Y; He ZX; Xu L; Yu PP; Sun QT; Li WX; Jie YL; Cao RG; **Cheng T&#42;**; Jiao SH&#42;;   
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Submitted **2023**  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  
[170]&nbsp; <span style="color:blue;"> Metastable 1T Phase PdO2 for Highly Efficient and Selective Chlorine Evolution Reaction  </span>  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Ma MJ; Xu L; Zhu WX; Liao F; Huang H; Shao Q; Chen JX; Feng K; Zhong J; Yang H; **Cheng T&#42;**; Liu Y&#42;; Shao MW&#42;; Kang ZH&#42;;   
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Submitted **2023**  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  
[169]&nbsp; <span style="color:blue;"> Atomically unraveling the structural evolution of surfaces and interfaces in metal halide perovskite quantum dots  </span>  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Ma MM; Zhang XL; Xu L; Chen X; Wang L; **Cheng T**; Wei F; Yuan JY&#42;; Shen BY&#42;;   
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Adv. Mater. **2023**, 35, 2300653  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;[https://doi.org/10.1002/adma.202300653](https://doi.org/10.1002/adma.202300653)  
  
[168]&nbsp; <span style="color:blue;"> Fast Interfacial Defluorination Kinetics Enables Stable Cycling of Low-Temperature Lithium Metal Batteries  </span>  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Li XP; Li MH; Liu Y; Jie YL; Chen YW; Li WX; Zhang YC; **Cheng T&#42;**; Gu M&#42;; Jiao SH; Cao RG&#42;;   
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Submitted **2023**  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  
[167]&nbsp; <span style="color:blue;"> Efficient CO Electroreduction to Methanol by CuRh Alloys with Isolated Rh Sites  </span>  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Zhang JB; Yu PP; Peng C; Lv XM; Liu ZZ; **Cheng T&#42;**; Zheng GF&#42;;   
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;ACS Catal. **2023**, 13, 7170–7177  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;[https://doi.org/10.1021/acscatal.3c00972](https://doi.org/10.1021/acscatal.3c00972)  
  
[166]&nbsp; <span style="color:blue;"> Impact of Lithium Nitrate Additives on the Solid Electrolyte Interphase in Lithium Metal Batteries  </span>  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Wang MW; Sun QT; Liu Y&#42;; Yan ZA; Xu QY; Wang B; Li YH&#42;; Wang XF; **Cheng T&#42;**;   
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Chinese J. Struc. Chem. **2023**, ASAP  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;[https://doi.org/10.1016/j.cjsc.2023.100203](https://doi.org/10.1016/j.cjsc.2023.100203)  
  
[165]&nbsp; <span style="color:blue;"> Enhancing Solid Electrolyte Interphase Formation on Lithium Metal Anodes with Fluorinated Aromatic Diluents  </span>  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Zhang Z; Liu Y&#42;; Sun QT; Yan ZG; Xu QY; Wang B; Li YH&#42;; **Cheng T&#42;**;   
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Submitted **2023**  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  
[164]&nbsp; <span style="color:blue;"> Fine-Tuned Molecular Design toward a Stable Solid Electrolyte Interphase on a Lithium Metal Anode from in silico Simulation  </span>  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Ma BY; Liu Y; Sun QT; Yu PP; Xu L; Yang H; Xie M; **Cheng T&#42;**;   
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Mater. Today Chem. **2023**, 33, 101735  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;[https://doi.org/10.1016/j.mtchem.2023.101735](https://doi.org/10.1016/j.mtchem.2023.101735)  
  
[163]&nbsp; <span style="color:blue;"> Elucidating Solid Electrolyte Interphase Formation in Sodium-Based Batteries: Key Reductive Reactions and Inorganic Composition  </span>  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Liu Y; Sun QT; Yue BT; Zhang YY; **Cheng T&#42;**;   
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;J. Mater. Chem. A **2023**, 11, 14640-14645  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;[https://doi.org/10.1039/D3TA01878D](https://doi.org/10.1039/D3TA01878D)  
  
[162]&nbsp; <span style="color:blue;"> Hydrogen Evolution and Suppression in Lithium Metal Battery  </span>  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Liu Y; Zhang JY; Wang XF; Sun QT; Zhang YY; Li H; **Cheng T&#42;**;   
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Submitted **2023**  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  
[161]&nbsp; <span style="color:blue;"> Regulating Inner Helmholtz Plane with A Small Addition of High Donor Additive for Efficient Zn Anode Reversibility  </span>  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Luo JR; Xu L; Zhou YJ; Yan TR; Shao YY; Yang DZ; Zhang L; Xia Z; Wang TH; Zhang L; **Cheng T&#42;**; Shao YL&#42;;   
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Angew. Chem., Int. Ed. **2023**, 62, e202302302  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;[https://doi.org/10.1002/anie.202302302](https://doi.org/10.1002/anie.202302302)  
  
[160]&nbsp; <span style="color:blue;"> Precisely Optimizing Polysulfides Adsorption and Conversion by Local Coordination Engineering for High-Performance Li-S Batteries  </span>  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Yuan C; Song XC; Zeng P; Liu GL; Zhou SH; Zhao G; Li HT; Yan TR; Mao J; Yang H; **Cheng T**; Wu JP&#42;; Zhang L&#42;;   
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Nano Energy **2023**, 110, 108353  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;[https://doi.org/10.1016/j.nanoen.2023.108353](https://doi.org/10.1016/j.nanoen.2023.108353)  
  
[159]&nbsp; <span style="color:blue;"> Enabling long-life 450 Wh kg-1 lithium metal battery with ultra-lean electrolyte  </span>  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Jie YL; Wang SY; Weng ST; Liu Y; Tang C; Li XP; Zhang ZF; Zhang YC; Chen YW; Huang FY; Xu YL; Li WX; Guo YZ; He ZX; Ren XD; Lu YH; Cao RG; Yan PF; **Cheng T&#42;**; Wang XF&#42;; Jiao SH&#42;; Xu DS&#42;;   
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Submitted **2023**  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  
[158]&nbsp; <span style="color:blue;"> Atomistic Origin of Portland Cement Paste Expansion from Ettringite Formation and its Effects on Concrete Durability: In-silico Study  </span>  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Botero AJ; **Cheng T**; Goddard WA; Liu LC;   
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Submitted **2023**  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  
[157]&nbsp; <span style="color:blue;"> Kinetic hindrance and LiF-rich interphase stabilize branched weakly solvating electrolytes on high-voltage cathodes  </span>  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Chen YW; Jie YL; Liu Y; Li MH; Zhang ZF; Tang C; Li WX; Li XP; Liu Y; Yi YH; Yan PF&#42;; Gu M&#42;; **Cheng T&#42;**; Cao RG&#42;; Jiao SH&#42;;   
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Submitted **2022**  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  
[156]&nbsp; <span style="color:blue;"> Programmable Synthesis of High-Entropy Nanoalloys for Efficient Ethanol Oxidation Reaction  </span>  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Li MF; Huang CM; Yang H; Wang Y; Song XC; **Cheng T**; Jiang JT; Lu YF; Liu MC; Yuan Q; Ye ZZ; Hu Z&#42;; Huang HW&#42;;   
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;ACS Nano **2023**, 17, 13659–13671  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;[https://doi.org/10.1021/acsnano.3c02762](https://doi.org/10.1021/acsnano.3c02762)  
  
[155]&nbsp; <span style="color:blue;"> Stable and oxidative charged Ru enhance the oxygen evolution reaction activity in two-dimensional ruthenium-iridium oxide  </span>  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Zhu WX; Song XC; Liao F; Huang H; Shao Q; Zhou YJ; Ma MJ; Wu J; Yang H; Yang HW; Wang M; Shi J; **Cheng T&#42;**; Shao MW&#42;; Liu Y&#42;; Kang ZH&#42;;   
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Nat. Commun. **2023**, 14, 5365  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;[https://doi.org/10.1038/s41467-023-41036-9](https://doi.org/10.1038/s41467-023-41036-9)  
  
[154]&nbsp; <span style="color:blue;"> Far-from-equilibrium electrosynthesis ramifies high-entropy alloy for alkaline hydrogen evolution  </span>  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Wang YN; Yang H; Zhang Z; Meng XY; **Cheng T**; Qin GW; Li S&#42;;   
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;J. Mater. Sci. Technol. **2023**, 166, 234-240  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;[https://doi.org/10.1016/j.jmst.2023.05.040](https://doi.org/10.1016/j.jmst.2023.05.040)  
  
[153]&nbsp; <span style="color:blue;"> Elucidating the Mechanism of Nonflammable Electrolytes in Lithium Metal Batteries  </span>  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Wu JY; Tang HC; Sun QT; Liu Y&#42;; Zhou QW; Feng S; Yu PP; **Cheng T&#42;**;   
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Submitted **2022**  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  
[152]&nbsp; <span style="color:blue;"> The operation active site of O2 reduction to H2O2 over ZnO  </span>  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Zhou YJ; Xu L; Wu J; Zhu WX; He TW; Yang H; Huang H; **Cheng T&#42;**; Liu Y&#42;; Kang ZH&#42;;   
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Energy Environ. Sci. **2023**, 16, 3526-3533  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;[https://doi.org/10.1039/D3EE01788E](https://doi.org/10.1039/D3EE01788E)  
  
[151]&nbsp; <span style="color:blue;"> Phase-dependent intrinsic oxygen evolution activity on iridium oxide  </span>  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Fan ZL; Zhou YJ; Sun QT; Zhu WX; Liao F; Shao Q; Yu K; Yang H; Huang H; Bao KL; Zhang TY; Cheng T; Liu Y&#42;; Shao MW&#42;; Kang ZH&#42;;   
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Submitted **2022**  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  
[150]&nbsp; <span style="color:blue;"> Metastable Hexagonal Phase SnO2Nanoribbons with Active Edge Sites for Efficient Hydrogen Peroxide Electrosynthesis in Neutral Media  </span>  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Zhang Y; Wang MW; Zhu WX; Fang MM; Ma MJ; Liao F&#42;; Shao Q; Yang H&#42;; **Cheng T**; Shao MW&#42;; Kang ZH&#42;;   
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Angew. Chem., Int. Ed. **2023**, 135, e202218924  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;[https://doi.org/10.1002/ange.202218924](https://doi.org/10.1002/ange.202218924)  
  
[149]&nbsp; <span style="color:blue;"> Origin of dendrite-free lithium deposition in concentrated electrolytes  </span>  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Chen YW; Li MH; Liu Y; Jie YL; Li WX; Huang FY; Li XP; He ZX; Ren XD; Chen YH; Meng XH; Cao RG&#42;; **Cheng T&#42;**; Gu M&#42;; Jiao SH&#42;;   
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Nat. Commun. **2023**, 14, 2655  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;[https://doi.org/10.1038/s41467-023-38387-8](https://doi.org/10.1038/s41467-023-38387-8)  
  
[148]&nbsp; <span style="color:blue;"> Preferential Decomposition of the Major Anion in a Dual-Salt Electrolyte Facilitates the Formation of Organic-Inorganic Composite Solid Electrolyte Interphase  </span>  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Qi F; Yu PP; Zhou QW; Liu Y&#42;; Sun QT; Ma BY; Ren XG&#42;; **Cheng T&#42;**;   
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;J. Chem. Phys. **2023**, 158, 104704  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;[https://doi.org/10.1063/5.0130686](https://doi.org/10.1063/5.0130686)  
  
[147]&nbsp; <span style="color:blue;"> The Hydrogen Evolution Reaction on Platinum (100) and (111) Surfaces is dominated by the Edges  </span>  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Huang ZH; **Cheng T**; Shah AH; Zhong GY; Wan CZ; Wang PQ; Ding MN; Huang J; Wan Z; Wang SB; Cai J; Peng BS; Liu HT; Huang Y&#42;; Goddard WA&#42;; Duan XF&#42;;   
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Submitted **2022**  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  
[146]&nbsp; <span style="color:blue;"> Temperature-dependent interphase formation and Li+ transport in lithium metal batteries  </span>  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Weng ST; Zhang X; Yang GJ; Zhang SM; Liu QY; Liu Y; **Cheng T**; Peng CX; Chen HX; Li YJ; Chen LQ; Wang ZX; Wang XF;   
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Nat. Commun. **2023**, 14, 4474  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;[https://www.nature.com/articles/s41467-023-40221-0](https://www.nature.com/articles/s41467-023-40221-0)  
  
[145]&nbsp; <span style="color:blue;"> Lattice and Surface Engineering of Ruthenium Nanostructures for Enhanced Hydrogen Oxidation Catalysis  </span>  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Dong YT; Sun QT; Zhan CH; Zhang JT; Yang H; **Cheng T**; Xu Y&#42;; Hu ZW; Pao CW; Geng HB; Huang XQ&#42;;   
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Adv. Funct. Mater. **2023**, 33, 2210328  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;[https://doi.org/10.1002/adfm.202210328](https://doi.org/10.1002/adfm.202210328)  
  
[144]&nbsp; <span style="color:blue;"> Nanoconfined molecular catalysts in integrated gas diffusion electrodes for high-current-density CO2 electroreduction  </span>  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Lv XZ; Liu Q; Yang H; Wang JH; Li XT; Zhu SQ; Yan JH; Wu AJ&#42;; **Cheng T&#42;**; Wu HB&#42;;   
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Adv. Funct. Mater. **2023**, 33, 2301334  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;[https://doi.org/10.1002/adfm.202301334](https://doi.org/10.1002/adfm.202301334)  
  
[143]&nbsp; <span style="color:blue;"> Correlating Electrolyte Solvation, Interphasial Structure and Deposition Morphology of Lithium Metal Anode in Ether-based Electrolytes  </span>  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Chen YW; Li MH; Liu Y; Jie YL; Li WX; Huang FY; Li XP; He ZX; Ren XD; Cao RG&#42;; **Cheng T&#42;**; Gu M&#42;; Jiao SH&#42;;   
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Submitted **2022**  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  
[142]&nbsp; <span style="color:blue;"> Pre-activation of CO2 at Cobalt Phthalocyanine-Mg(OH)2 Interface for Enhanced Turnover Rate  </span>  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;FL Lyu; BY Ma; XL Xie; DQ Song; YB Lian; H Yang; W Hua; Sun Sun; J Zhong; Z Deng; **Cheng T&#42;**; Y Peng&#42;;   
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Adv. Funct. Mater. **2023**, 33, 2214609  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;[https://doi.org/10.1002/adfm.202214609](https://doi.org/10.1002/adfm.202214609)  
  
[141]&nbsp; <span style="color:blue;"> The lattice strain dominated catalytic activity in single-metal nanosheets  </span>  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Wang M; Sun QT; Fan ZL; Zhu WX; Wu J; Zhou YJ; Yang H; Huang H; Ma MJ; **Cheng T&#42;**; Shao MW&#42;; kang ZH&#42;;   
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;J. Mater. Chem. A **2023**, 11, 4037-4044  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;[https://doi.org/10.1039/D2TA08454F](https://doi.org/10.1039/D2TA08454F)  
  
[140]&nbsp; <span style="color:blue;"> Machine Learning Predicts the X-ray Photoelectron Spectroscopy of the Solid Electrolyte Interface of Lithium Metal Battery  </span>  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Sun QT; Xiang Y; Liu Y; Xu L; Leng TL; Ye YF; Fortunelli A&#42;; Goddard WA&#42;; **Cheng T&#42;**;   
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;J. Phys. Chem. Lett. **2022**, 13, 8047–8054  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;[https://doi.org/10.1021/acs.jpclett.2c02222](https://doi.org/10.1021/acs.jpclett.2c02222)  
  
[139]&nbsp; <span style="color:blue;"> Molecular Crowding Effect Mimicking Cold Resistant Plant to Stabilize Zinc Anode with Wider Service Temperature Range  </span>  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Ren HZ; Li S; Wang B&#42;; Zhang YY; Wang T; Lv Q; Zhang XY; Wang L; Han X; Jin F; Bao CY; Zhang N; Yan PF; Wang DL&#42;; **Cheng T&#42;**; Liu HK; Dou SX&#42;;   
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Adv. Mater. **2023**, 35, 2208237  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;[https://doi.org/10.1002/adma.202208237](https://doi.org/10.1002/adma.202208237)  
  
[138]&nbsp; <span style="color:blue;"> The lattice strain dominated catalytic activity in single-metal nanosheet  </span>  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Wang M; Sun QT; Fan ZL&#42;; Zhu WX; Liao F; Wu J; Zhou YJ; Yang H; Huang H; Ma MJ; **Cheng T&#42;**; Shao Q&#42;; Shao MW&#42;; Kang ZH&#42;;   
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;J. Mater. Chem. A **2023**, 11, 4037-4044  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;[https://doi.org/10.1039/D2TA08454F](https://doi.org/10.1039/D2TA08454F)  
  
[137]&nbsp; <span style="color:blue;"> DFT-ReaxFF Hybrid Molecular Dynamics Investigation of the Decomposition Effects of Localized High-Concentration Electrolyte in Lithium Metal Batteries: LiFSI/DME/TFEO  </span>  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Lu YM; Sun QT; Liu Y&#42;; Yu PP; Zhang YY; Lu JC; Huang HC; Yang H&#42;; **Cheng T&#42;**;   
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Phys. Chem. Chem. Phys. **2022**, 24, 18684-18690  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;[https://doi.org/10.1039/D2CP02130G](https://doi.org/10.1039/D2CP02130G)  
  
[136]&nbsp; <span style="color:blue;"> Enhanced electroreduction of CO2 to C2+ products on heterostructured Cu/oxide electrodes  </span>  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Li XT; Liu Q; Wang JH; Meng DC; Shu YJ; Lv XZ; Zhao B; Yang H; **Cheng T**; Gao QS; Li LS; Wu HB&#42;;   
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Chem **2022**, 8, 2148-2162  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;[https://doi.org/10.1016/j.chempr.2022.04.004](https://doi.org/10.1016/j.chempr.2022.04.004)  
  
[135]&nbsp; <span style="color:blue;"> Unveiling the Local Structure and Electronic Properties of PdBi Surface Alloy for Selective Hydrogenation of Propyne  </span>  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Wang XC; Chu MY; Wang MW; Zhong QX; Chen JT; Wang ZQ; Cao MH; Yang H; **Cheng T**; Zhang Q; Chen JX; Sham TK;   
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;ACS Nano **2022**, 16, 16869  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;[https://doi.org/10.1021/acsnano.2c06834](https://doi.org/10.1021/acsnano.2c06834)  
  
[134]&nbsp; <span style="color:blue;"> Dynamics at the In2O3/Pd(111) Interface: Pd-promoted Room-Temperature Reduction of In2O3 and Reduction-Driven Structural Dynamics  </span>  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Zhang XQ&#42;; Goodman K; Yuan Q; Tong X; Su ZK; **Cheng T&#42;**; Blum M&#42;;   
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Submitted **2022**  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  
[133]&nbsp; <span style="color:blue;"> Origin of the exceptional selectivity of NaA zeolite for the radioactive isotope of 90Sr2+  </span>  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Hao WF; Yan NN; Xie M; Yan XJ; Guo XL; Bai P; **Cheng T&#42;**; Guo P; Yan WF&#42;;   
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Inorg. Chem. Front. **2022**, 9, 6258  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;[https://doi.org/10.1039/D2QI01958B](https://doi.org/10.1039/D2QI01958B)  
  
[132]&nbsp; <span style="color:blue;"> Advanced Characterization and Simulation Methods for Promoting Mechanistic Understanding of Lithium Deposition and Solid-Electrolyte Interphase (SEI) Formation: Recent Progress, Limitations, and Future Perspectives  </span>  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;X YL; Dong K; J YL; Adelhelm PE; Chen YW; Xu L; Yu PP; Kim JH; Kochovski Z; Yu ZL; Li WX; Lebeau J; Yang SH; Cao RG; Jiao SH; **Cheng T&#42;**; Manke I&#42;; Lu Y&#42;;   
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Adv. Energy Mater. **2022**, 12, 2200398  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;[https://doi.org/10.1002/aenm.202200398](https://doi.org/10.1002/aenm.202200398)  
  
[131]&nbsp; <span style="color:blue;"> Multiscale Simulation of Solid Electrolyte Interphase  </span>  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Yu PP; Xu L; Ma BY; Yang H; Liu Y; **Cheng T&#42;**;   
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Energy Storage Science and Technology **2022**, 11, 921-928  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;[https://esst.cip.com.cn/CN/10.19799/j.cnki.2095-4239.2022.0046](https://esst.cip.com.cn/CN/10.19799/j.cnki.2095-4239.2022.0046)  
  
[130]&nbsp; <span style="color:blue;"> Stimulating the pre-catalyst redox reaction and proton-electron transfer process of cobalt phthalocyanine for CO2 electroreduction  </span>  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Li HY; Wei J&#42;; Gan L; **Cheng T**; Li J&#42;;   
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;J. Phys. Chem. C **2022**, 126, 9665–9672  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;[https://doi.org/10.1021/acs.jpcc.2c01125](https://doi.org/10.1021/acs.jpcc.2c01125)  
  
[129]&nbsp; <span style="color:blue;"> Boosting electrocatalytic CO2–to–ethanol production via asymmetric C–C coupling  </span>  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Wang PT; Yang H; Cheng Y; Tang C; Wu Y; Zheng Y; **Cheng T**; Davey K; Huang XQ&#42;; Qiao SZ&#42;;   
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Nat. Commun. **2022**, 13, 3754  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;[https://doi.org/10.1038/s41467-022-31427-9](https://doi.org/10.1038/s41467-022-31427-9)  
  
[128]&nbsp; <span style="color:blue;"> Determining Hydronium pKa on Platinum Surface and Impact on Hydrogen Evolution Reaction  </span>  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Zhong GY; **Cheng T**; Huang ZH; Wan CZ; Shah AH; Wang SB; Huang Y&#42;; Goddard WA&#42;; Duan Xiangfeng&#42;;   
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Proc. Natl. Acad. Sci. U.S.A. **2022**, 119, e2208187119  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;[https://doi.org/10.1073/pnas.2208187119](https://doi.org/10.1073/pnas.2208187119)  
  
[127]&nbsp; <span style="color:blue;"> Coherent Hexagonal Platinum Skin on Nickel Nanocrystals for Enhanced Hydrogen Evolution Activity  </span>  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Liu K; Yang H; Jiang YL; Liu ZJ; Zhang SM; Zhang ZX; Lu YM; **Cheng T&#42;**; Terasaki O&#42;; Zhang Q&#42;; Gao CB&#42;;   
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Nat. Commun. **2023**, 14, 2424  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;[https://doi.org/10.1038/s41467-023-38018-2](https://doi.org/10.1038/s41467-023-38018-2)  
  
[126]&nbsp; <span style="color:blue;"> Formation of Linear Oligomers in Solid Electrolyte Interphase via Two-Electron Reduction of Ethylene Carbonate  </span>  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Liu Yue; Wu Yu; Sun Qintao; Ma Bingyun; Yu Peiping; Xu Liang; Xie Miao; Yang Hao; **Cheng T&#42;**;   
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Adv. Theory Simul. **2022**, 5, 2100612  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;[https://doi.org/10.1002/adts.202100612](https://doi.org/10.1002/adts.202100612)  
  
[125]&nbsp; <span style="color:blue;"> Single-site Pt doped RuO2 hollow nanospheres with interstitial C for high-performance acidic overall water splitting  </span>  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Wang J; Yang H; Li F; Li LG; Wu JB; Liu SH; **Cheng T**; Xu Y&#42;; Shao Q; Huang XQ&#42;;   
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Sci. Adv. **2022**, 8, eabl9271  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;[https://doi.org/10.1126/sciadv.abl9271](https://doi.org/10.1126/sciadv.abl9271)  
  
[124]&nbsp; <span style="color:blue;"> TiH2 quantum dots exfoliated via facile sonication as bifunctional electrocatalysts for Li-S batteries  </span>  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Yan TR; Wu Y; Gong F; Cheng C; Mao J; Dai KH; Cheng L&#42;; **Cheng T&#42;**; Zhang L&#42;;   
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;ACS Appl. Mater. Interfaces **2022**, 14, 6937–6944  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;[https://doi.org/10.1021/acsami.1c23815](https://doi.org/10.1021/acsami.1c23815)  
  
[123]&nbsp; <span style="color:blue;"> Harmonizing Graphene Laminate Spacing and Zn-ion Solvated Structure toward Efficient Compact Capacitive Charge Storage  </span>  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Luo JR; Xu L; Wang Q; Liu HM; Wang YS; Shao YY; Wang ML; Yang DZ; Li S; Zhang L; Xia Z; **Cheng T&#42;**; Shao YL&#42;;   
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Adv. Funct. Mater **2022**, 32, 2112151  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;[https://doi.org/10.1002/adfm.202112151](https://doi.org/10.1002/adfm.202112151)  
  
[122]&nbsp; <span style="color:blue;"> Exclusive CO-to-acetate electroconversion via hydroxide-paired CO–CO coupling reaction  </span>  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Cui CY; Yang H; Wen YZ; Niu WZ; Ni FL; Yu PP; Jiang TW; Wang N; Ye JY; Finfrock YZ; Zhang XD; Chen PN; Cai WB; Xia YY; **Cheng T&#42;**; Li J&#42;; Peng HS&#42;; Zhang B&#42;;   
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Submitted **2022**  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  
[121]&nbsp; <span style="color:blue;"> Multiscale Simulation of Solid Electrolyte Interface Formation in Fluorinated Diluted Electrolyte with Lithium Anode  </span>  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Yu PP; Sun QT; Liu Y; Ma BY; Yang H; Xie M; **Cheng T&#42;**;   
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;ACS Appl. Mater. Interfaces **2022**, 14, 7972–7979  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;[https://doi.org/10.1021/acsami.1c22610](https://doi.org/10.1021/acsami.1c22610)  
  
[120]&nbsp; <span style="color:blue;"> From n-alkane to polyacetylene on Cu (110): Linkage modulation in Chain Growth  </span>  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Hao ZM; Zhang JJ; Xie M; Li XC; Wang LN; Liu Y; Niu KF; Wang JB; Song LY; **Cheng T**; Zhang HM; Chi LF&#42;;   
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Sci. China Chem. **2022**, 8, 733–739  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;[https://doi.org/10.1007/s11426-021-1213-2](https://doi.org/10.1007/s11426-021-1213-2)  
  
[119]&nbsp; <span style="color:blue;"> The exclusive surface and electronic effects of Ni on promoting the activity of Pt towards alkaline hydrogen oxidation  </span>  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Wang KC; Yang H; Zhang JT; Ren GM; **Cheng T**; Xu Y&#42;; Huang XQ&#42;;   
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Nano Res. **2022**, 15, 5865-5872  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;[https://doi.org/10.1007/s12274-022-4228-3](https://doi.org/10.1007/s12274-022-4228-3)  
  
[118]&nbsp; <span style="color:blue;"> Ligand-Mediated Self-Terminating Growth of Single-Atom Pt on Au Nanocrystals for Improved Formic Acid Oxidation Activity  </span>  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Liu MX; Liu ZJ; Xie M; Zhang ZX; Zhang SM; **Cheng T&#42;**; Gao CB&#42;;   
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Adv. Energy Mater. **2022**, 12, 2103195  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;[https://doi.org/10.1002/aenm.202103195](https://doi.org/10.1002/aenm.202103195)  
  
[117]&nbsp; <span style="color:blue;"> Rh/RhOx nanosheets as pH-universal bifunctional catalysts for hydrazine oxidation and hydrogen evolution reactions  </span>  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Yang JJ; Xu L; Zhua WX; Xie M; Liao F&#42;; **Cheng T&#42;**; Kang ZH; Shao MW&#42;;   
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;J. Mater. Chem. A **2022**, 10, 1891-1898  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;[https://doi.org/10.1039/D1TA09391F](https://doi.org/10.1039/D1TA09391F)  
  
[116]&nbsp; <span style="color:blue;"> Reduction Mechanism of Solid Electrolyte Interphase Formation on Lithium Metal Anode: Fluorine-rich Electrolyte  </span>  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Wu Y; Sun QT; Liu Y; Yu PP; Ma BY; Yang H; Xie M; **Cheng T&#42;**;   
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;J. Electrochem. Soc. **2022**, 169, 010503  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;[https://doi.org/10.1149/1945-7111/ac44bc](https://doi.org/10.1149/1945-7111/ac44bc)  
  
[115]&nbsp; <span style="color:blue;"> In Situ Formation of Circular and Branched Oligomers in Localized High Concentration Electrolyte at Lithium−metal Solid Electrolyte Interphase: A Hybrid ab initio and Reactive Molecular Dynamics  </span>  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Liu Y; Sun QT; Yu PP; Ma BY; Yang H; Zhang JY; Xie M; **Cheng T&#42;**;   
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;J. Mater. Chem. A **2022**, 10, 632-639  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;[https://doi.org/10.1039/D1TA08182A](https://doi.org/10.1039/D1TA08182A)  
  
[114]&nbsp; <span style="color:blue;"> Promoting Oxidation State Transition of Nickel in Single-Layer NiFeB Hydroxide Nanosheets for Efficient Oxygen Evolution  </span>  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Bai YK; Wu Y; Zhou XC; Ye YF; Nie KQ; Wang JO; Xie M; Zhang ZX; Liu ZJ; **Cheng T&#42;**; Gao CB&#42;;   
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Nat. Commun. **2022**, 13, 6094  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;[https://doi.org/10.1038/s41467-022-33846-0](https://doi.org/10.1038/s41467-022-33846-0)  
  
[113]&nbsp; <span style="color:blue;"> Molecular Understanding of Interphase Formation via Operando Polymerization on Lithium Metal Anode  </span>  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Jie YL; Xu YL; Chen YW; Xie M; Liu Y; Huang FY; L ZW; Kochovski Z; Zheng L; Song PD; Hu CS; Qi ZM; Li XP; Wang SY; Shen YB; Chen LW; You YZ; Cao RG; Lu Y&#42;; **Cheng T&#42;**; Xu K&#42;; Jiao SH&#42;; Goddard WA;   
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Cell Reports Physical Science **2022**, 3, 101057  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;[https://doi.org/10.1016/j.xcrp.2022.101057](https://doi.org/10.1016/j.xcrp.2022.101057)  
  
[112]&nbsp; <span style="color:blue;"> Au-activated N motifs in Non-coherent Cupric Porphyrin Metal Organic Frameworks for Promoting and Stabilizing Ethylene Production  </span>  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Zhang X; Xie M; Xie XL; Xiong LK; Sun H; Lu YT; Mu QQ; Rummeli MH; Xu JB; Li S; Zhong J; Deng Z; Ma BY; **Cheng T&#42;**; Goddard WA&#42;; Peng Y&#42;;   
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Nat. Commun. **2022**, 13, 63  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;[https://doi.org/10.1038/s41467-021-27768-6](https://doi.org/10.1038/s41467-021-27768-6)  
  
[111]&nbsp; <span style="color:blue;"> Hofmann-Type Metal–Organic Framework Nanosheets for Oxygen Evolution  </span>  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Wang TT; Wu Y; Han Y; Xu PW; Yang H; Jiang YB; Wen JW; J WJ&#42;; **Cheng T**;   
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;ACS Appl. Nano Mater. **2021**, 4, 14161–14168  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;[https://doi.org/10.1021/acsanm.1c03619](https://doi.org/10.1021/acsanm.1c03619)  
  
[110]&nbsp; <span style="color:blue;"> Self-supported hierarchical crystalline carbon nitride arrays with triazine-heptazine heterojunctions for highly efficient photoredox catalysis  </span>  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Sun ZZ; Dong HZ; Yuan Q; Tang YY; Wang W; Jiang YB; Wen JW; He JQ; **Cheng T**; Huang LM&#42;;   
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Chem. Eng. Sci. **2022**, 435, 134865  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;[https://doi.org/10.1016/j.cej.2022.134865](https://doi.org/10.1016/j.cej.2022.134865)  
  
[109]&nbsp; <span style="color:blue;"> In-silico Screening the Nitrogen Reduction Reaction on Single-Atom Electrocatalysts Anchored on MoS2  </span>  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Xu L; Xie M; Yang H; Yu PP; Ma BY; **Cheng T&#42;**; Goddard WA&#42;;   
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Top. Catal. **2022**, 65, 234–241  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;[https://doi.org/10.1007/s11244-021-01546-6](https://doi.org/10.1007/s11244-021-01546-6)  
  
[108]&nbsp; <span style="color:blue;"> Facet-selective deposition of ultrathin Al2O3 on copper nanocrystals for highly stable CO2 electroreduction to ethylene  </span>  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Li H; Yu PP; Lei RB; Wen P; Ma X; Zeng GS; Toma FM; Qiu YJ; Geyer SM; Wang XW; **Cheng T&#42;**; Drisdell W&#42;;   
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Angew. Chem. Int. Ed. **2021**, 60, 24838-24843  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;[https://doi.org/10.1002/anie.202109600](https://doi.org/10.1002/anie.202109600)  
  
[107]&nbsp; <span style="color:blue;"> Anomalous Size Effect of Pt Ultrathin Nanowires on Oxygen Reduction Reaction  </span>  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Yao ZY; Yuan YL; **Cheng T**; Sun TL; Lu YF; Galindo P; Yang ZL; Gao L; Xu L; Yang H; Huang HW&#42;;   
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Nano Lett. **2021**, 21, 9354–9360  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;[https://doi.org/10.1021/acs.nanolett.1c03805](https://doi.org/10.1021/acs.nanolett.1c03805)  
  
[106]&nbsp; <span style="color:blue;"> Specific Site Modulation in the 2D Hofmann Type Metal Organic Frameworks Efficient for Oxygen Evolution Reaction  </span>  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Wang TT; Wu Yu; Han Y; Xu PW; Feng XZ; Yang H&#42;; Ji WJ&#42;; **Cheng T**;   
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Submitted **2021**  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  
[105]&nbsp; <span style="color:blue;"> Assembling covalent organic framework membranes with superhigh ion exchange capacity  </span>  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Wang XY; Shi BB; Yang H; Guan JY; Xu L; Fan CY; You XD; Wang YN; Zhang Z; **Cheng T**; Zhang RN&#42;; Jiang ZY&#42;;   
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Nat. Commun. **2021**, 13, 1020  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;[https://doi.org/10.1038/s41467-022-28643-8](https://doi.org/10.1038/s41467-022-28643-8)  
  
[104]&nbsp; <span style="color:blue;"> Multi-scale Simulation Reveals the Decomposition Mechanism of Electrolyte on Lithium Metal Electrode  </span>  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Zhang YY; Liu Y; Yu PP; Du WX; Ma BY; Xie M; Yang H; **Cheng T&#42;**;   
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;J. Electrochem. **2021**, 28, 2105181  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;[http://electrochem.xmu.edu.cn/CN/10.13208/j.electrochem.210518](http://electrochem.xmu.edu.cn/CN/10.13208/j.electrochem.210518)  
  
[103]&nbsp; <span style="color:blue;"> Reaction Mechanism on Sulphur Doped Ni Single-Atom Catalysis for CO2 Reduction Reaction  </span>  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Yuan Q; Li YY; Yu PP; Ma BY; Xu L; Sun QT; Yang H&#42;; Xie M&#42;; **Cheng T&#42;**;   
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;J. Exp. Nanosci. **2021**, 16, 256-265  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;[https://doi.org/10.1080/17458080.2021.1959032](https://doi.org/10.1080/17458080.2021.1959032)  
  
[102]&nbsp; <span style="color:blue;"> Predicted operando Polymerization at Lithium Anode via Boron Insertion  </span>  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Liu Y; Yu PP; Sun QT; Wu Y; Xie M; Yang H; **Cheng T&#42;**; Goddard WA;   
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;ACS Energy Lett. **2021**, 6, 2320  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;[https://doi.org/10.1021/acsenergylett.1c00907](https://doi.org/10.1021/acsenergylett.1c00907)  
  
[101]&nbsp; <span style="color:blue;"> Atomistic Mechanisms for catalytic transformations of NO to NH3, N2O, and N2 by Pd  </span>  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Yu PP; Wu Y; Yang H; Xie M; **Cheng T&#42;**; Goddard WA&#42;;   
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Chin. J. Chem. Phys **2023**, 94  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;[https://doi.org/10.1063/1674-0068/cjcp2109153](https://doi.org/10.1063/1674-0068/cjcp2109153)  
  
[100]&nbsp; <span style="color:blue;"> Core-Shell Nanoparticle with Tensile Strain Enables Highly Efficient Electrochemical Ethanol Oxidation  </span>  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Liu MX; Xie M; Jiang YL; Liu ZJ; Lu YM; Zhang SM; Zhang ZX; Liu K; Zhang Q; **Cheng T&#42;**; Gao CB&#42;;   
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;J. Mater. Chem. A **2021**, 9, 15373  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;[https://doi.org/10.1039/D1TA03365D](https://doi.org/10.1039/D1TA03365D)  
  
[99]&nbsp;&nbsp; <span style="color:blue;"> Boosting Hydrogen Production with Ultralow Working Voltage by Selenium Vacancy Enhanced Ultrafine Platinum-Nickel Nanowires  </span>  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Jin Y; Zhang Z; Yang H&#42;; Wang PT; Shen CQ; **Cheng T**; Huang XQ&#42;; Shao Q&#42;;   
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;SmartMat **2022**, 3, 130-141  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;[https://doi.org/10.1002/smm2.1083](https://doi.org/10.1002/smm2.1083)  
  
[98]&nbsp;&nbsp; <span style="color:blue;"> Graphitization of low-density amorphous carbon for electrocatalysis electrodes from ReaxFF reactive dynamics  </span>  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Hossain D; Zhang Q; **Cheng T**; Goddard WA&#42;; Luo ZT&#42;;   
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Carbon **2021**, 183, 940-947  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;[https://doi.org/10.1016/j.carbon.2021.07.080](https://doi.org/10.1016/j.carbon.2021.07.080)  
  
[97]&nbsp;&nbsp; <span style="color:blue;"> Bimetallic PdAu Nanoframes for Electrochemical H2O2 Production in Acids  </span>  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Zhao X; Yang H; Xu J; **Cheng T**; Li YG&#42;;   
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;ACS Mater. Lett. **2021**, 3, 996  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;[https://doi.org/10.1021/acsmaterialslett.1c00263](https://doi.org/10.1021/acsmaterialslett.1c00263)  
  
[96]&nbsp;&nbsp; <span style="color:blue;"> Exceptionally active and stable RuO2 with interstitial carbon for water oxidation in acid  </span>  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Wang J; Cheng C; Yuan Q; Yang H; Meng FP; Zhang QH; G L; Cao JL; Li LG; Haw SC; Shao Q; Zhang L; **Cheng T**; Jiao F; Huang XQ&#42;;   
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Chem **2021**, 8, 1673-1687  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;[https://doi.org/10.1016/j.chempr.2022.02.003](https://doi.org/10.1016/j.chempr.2022.02.003)  
  
[95]&nbsp;&nbsp; <span style="color:blue;"> Inorganic cation-tailored “trapdoor” effect of the silicoaluminophosphate zeolite for highly selective CO2 separation  </span>  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Wang XH; Yan NN; Xie M; Liu PX; Bai P; Su HP; Wang BY; Wang YZ; Li LB; **Cheng T**; Guo P&#42;; Yan WF&#42;; Yu JH&#42;;   
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Chem. Sci. **2021**, 12, 8803  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;[https://doi.org/10.1039/D1SC00619C](https://doi.org/10.1039/D1SC00619C)  
  
[94]&nbsp;&nbsp; <span style="color:blue;"> Ultrathin Pt-Cu-Ni Ternary Alloy Nanowires with Multimetallic Interplay for Boosted Methanol Oxidation Activity  </span>  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Zhang ZX; Xie M; Liu ZJ; Lu YM; Zhang SM; Liu MX; Liu Kai; **Cheng T&#42;**; Gao CB&#42;;   
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;ACS Appl. Energy Mater. **2021**, 4, 6824  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;[https://pubs.acs.org/doi/full/10.1021/acsaem.1c00952](https://pubs.acs.org/doi/full/10.1021/acsaem.1c00952)  
  
[93]&nbsp;&nbsp; <span style="color:blue;"> Insight of the pH-dependent Behavior of N Doped Carbon for Oxygen Reduction Reaction by First-principles Calculations  </span>  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Chen MP; Ping Y&#42;; Li Y&#42;; **Cheng T&#42;**;   
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;J. Phys. Chem. C **2021**, 125, 26429–26436  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;[https://doi.org/10.1021/acs.jpcc.1c07362](https://doi.org/10.1021/acs.jpcc.1c07362)  
  
[92]&nbsp;&nbsp; <span style="color:blue;"> Approaching 100% Selectivity for Electrochemical CO2 Reduction to CO at Low Potential on Ag Using a Surface Additive  </span>  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Buckley A; **Cheng T**; Oh MH; Su G; Garrison J; Utan S; Zhu CH; Toste DF; Goddard III WA&#42;; Toma FM&#42;;   
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;ACS Catal. **2021**, 11, 9034  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;[https://doi.org/10.1021/acscatal.1c00830](https://doi.org/10.1021/acscatal.1c00830)  
  
[91]&nbsp;&nbsp; <span style="color:blue;"> Sulfur-doped Graphene Anchoring of Ultrafine Au25 Nanoclusters for Electrocatalysis  </span>  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Li MF; Zhang B; **Cheng T**; Yu SM; Louisia S; Chen CB; Chen SP; Cestellos-Blanco S; Goddard III WA; Yang PD&#42;;   
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Nano Res. **2021**, 14, 3509–3513  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;[https://doi.org/10.1007/s12274-021-3561-2](https://doi.org/10.1007/s12274-021-3561-2)  
  
[90]&nbsp;&nbsp; <span style="color:blue;"> Pathway of in situ Polymerization of 1,3-dioxolane in LiPF6 Electrolyte on Li Metal Anode  </span>  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Xie M; Wu Y; Liu Y; Yu PP; Jia R; Ye YF; Goddard III WA&#42;; **Cheng T&#42;**;   
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Mater. Today Energy **2021**, 21, 100730  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;[https://doi.org/10.1016/j.mtener.2021.100730](https://doi.org/10.1016/j.mtener.2021.100730)  
  
[89]&nbsp;&nbsp; <span style="color:blue;"> Predictions of Chemical Shifts for Reactive Intermediates in CO2 Reduction under operando Conditions  </span>  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Yang Hao; Negreiros F; Sun QT; Xie M; Sementa L; Ye YF; Fortunelli A&#42;; Goddard III WA&#42;; **Cheng T&#42;**;   
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;ACS Appl. Mater. Interfaces **2021**, 13, 31554  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;[https://pubs.acs.org/doi/10.1021/acsami.1c02909](https://pubs.acs.org/doi/10.1021/acsami.1c02909)  
  
[88]&nbsp;&nbsp; <span style="color:blue;"> Effects of High and Low Salt Concentration in Electrolytes at Lithium−Metal Anode Surfaces using DFT-ReaxFF Hybrid Molecular Dynamics Method   </span>  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Liu Y; Sun QT; Yu PP; Wu Y; Xu L; Yang H; Xie M; **Cheng T&#42;**; Goddard III WA;   
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;J. Phys. Chem. Lett. **2021**, 12, 2922–2929  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;[https://doi.org/10.1021/acs.jpclett.1c00279](https://doi.org/10.1021/acs.jpclett.1c00279)  
  
[87]&nbsp;&nbsp; <span style="color:blue;"> The DFT-ReaxFF Hybrid Molecular Dynamics Method with Application to the Reductive Decomposition Reaction of the TFSI and DOL Electrolyte at the Lithium-Metal Anode Surfaces  </span>  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Liu Y; Yu PP; Wu Y; Yang H; Miao X; Huai LY; Goddard WA&#42;; **Cheng T&#42;**;   
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;J. Phys. Chem. Lett. **2021**, 12, 1300  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;[https://doi.org/10.1021/acs.jpclett.0c03720](https://doi.org/10.1021/acs.jpclett.0c03720)  
  
[86]&nbsp;&nbsp; <span style="color:blue;"> Auto-bifunctional Mechanism of Jagged Pt Nanowire for Hydrogen Evolution Kinetics via End-to-End In Situ Simulation  </span>  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Gu GH; Lim JH; Wan CZ; **Cheng T**; Pu HT; Kim S; Noh J; Choi C; Kim J; Goddard WA&#42;; Duan XF&#42;; Jung YS&#42;;   
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;J. Am. Chem. Soc. **2021**, 143, 5355–5363  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;[https://doi.org/10.1021/jacs.0c11261](https://doi.org/10.1021/jacs.0c11261)  
  
[85]&nbsp;&nbsp; <span style="color:blue;"> Selective CO2 Electrochemical Reduction Enabled by a Tri-component Copolymer Modifier on a Copper Surface  </span>  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Wang JC; **Cheng T**; Fenwick AQ; Rosas-Hernández A; Ko JH; Gan Q; Goddard WA&#42;; Grubbs RH&#42;;   
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;J. Am. Chem. Soc. **2021**, 143, 2857–2865  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;[https://doi.org/10.1021/jacs.0c12478](https://doi.org/10.1021/jacs.0c12478)  
  
[84]&nbsp;&nbsp; <span style="color:blue;"> Tri-fluorinated Keto-Enol Tautomeric Switch in Probing Domain Rotation of a G Protein-Coupled Receptor  </span>  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Wang XD; Zhao WJ; Sameer AM; Lu YM; **Cheng T**; Jesper M; Ye LB&#42;;   
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Bioconjugate Chem. **2021**, 32, 99  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;[https://doi.org/10.1021/acs.bioconjchem.0c00670](https://doi.org/10.1021/acs.bioconjchem.0c00670)  
  
[83]&nbsp;&nbsp; <span style="color:blue;"> Synergized Cu/Pb Core/Shell Electrocatalyst for High-Efficiency CO2 Reduction to C2+ Liquids  </span>  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Wang PT; Yang H; Xu Y; Huang XQ&#42;; Wang J; Zhong M; **Cheng T**; Shao Q&#42;;   
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;ACS Nano **2021**, 15, 1039–1047  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;[https://doi.org/10.1021/acsnano.0c07869](https://doi.org/10.1021/acsnano.0c07869)  
  
[82]&nbsp;&nbsp; <span style="color:blue;"> Efficient Direct H2O2 Synthesis Enabled by PdPb Nanorings via Inhibiting the O−O Bond Cleavage in O2 and H2O2  </span>  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Cao KL; Yang H; Bai SX; Xu Y&#42;; Yang CY; Wu Y; Xie M; Zhao X; **Cheng T**; Shao Q; Huang XQ&#42;;   
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;ACS Catal. **2021**, 11, 1106–1118  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;[https://doi.org/10.1021/acscatal.0c04348](https://doi.org/10.1021/acscatal.0c04348)  
  
[81]&nbsp;&nbsp; <span style="color:blue;"> Alloying Nickel with Molybdenum Significantly Accelerates Alkaline Hydrogen Electrocatalysis  </span>  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Wang M; Yang H; Shi JN; Chen YF; Zhou Y; Wang LG; Di SJ; Zhao X; Zhong J; **Cheng T**; Zhou W; Li YG&#42;;   
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Angew. Chem. Int. Ed. **2021**, 60, 5771-5777  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;[https://doi.org/10.1002/anie.202013047](https://doi.org/10.1002/anie.202013047)  
  
[80]&nbsp;&nbsp; <span style="color:blue;"> Fastening Brˉ ions at Copper-Molecule Interface Enables Highly Efficient Electroreduction of CO2 to Ethanol  </span>  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Wang JH; Yang H; Liu QQ; Liu Q; Li XT; Lv XZ; **Cheng T&#42;**; Wu HB&#42;;   
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;ACS Energy Lett. **2021**, 6, 437–444  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;[https://doi.org/10.1021/acsenergylett.0c02364](https://doi.org/10.1021/acsenergylett.0c02364)  
  
[79]&nbsp;&nbsp; <span style="color:blue;"> Bioinspired Activation of N2 on Asymmetrical Coordinated Fe grafted 1T MoS2 at Room Temperature  </span>  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Guo JJ; Wang MY; Xu L; Li XM; Asma I; George S; Yang H; Xie M; Guo JJ; Zai JT&#42;; Feng ZX; Guo JJ; **Cheng T&#42;**; Qian XF&#42;;   
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Chin. J. Chem. **2021**, 39, 1898-1904  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;[https://doi.org/10.1002/cjoc.202000675](https://doi.org/10.1002/cjoc.202000675)  
  
[78]&nbsp;&nbsp; <span style="color:blue;"> London Dispersion Corrections to Density Functional Theory for Transition Metals Based on Fitting to Experimental Temperature-Programmed Desorption of Benzene Monolayers  </span>  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Yang H; **Cheng T&#42;**; Goddard WA&#42;;   
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;J. Phys. Chem. Lett **2021**, 12, 73–79  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;[https://doi.org/10.1021/acs.jpclett.0c03126](https://doi.org/10.1021/acs.jpclett.0c03126)  
  
[77]&nbsp;&nbsp; <span style="color:blue;"> Theoretical Research on the Electroreduction of Carbon Dioxide  </span>  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Yuan Q; Yang H; Xie M; **Cheng T&#42;**;   
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Acta Phys. -Chim. Sin. **2021**, 37, 2010040  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;[https://doi.org/10.3866/PKU.WHXB202010040](https://doi.org/10.3866/PKU.WHXB202010040)  
  
[76]&nbsp;&nbsp; <span style="color:blue;"> Compressed Intermetallic PdCu for Enhanced Electrocatalysis  </span>  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Espinosa M; **Cheng T**; Abatemarco L; Choi CS; Pan XQ; Goddard WA; Zhao ZP&#42;; Huang Y&#42;;   
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;ACS Energy Lett. **2020**, 5, 3672–3680  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;[https://doi.org/10.1021/acsenergylett.0c01959](https://doi.org/10.1021/acsenergylett.0c01959)  
  
[75]&nbsp;&nbsp; <span style="color:blue;"> Te-Doped Pd Nanocrystal for Electrochemical Urea Production by Efficiently Coupling Carbon Dioxide Reduction with Nitrite Reduction  </span>  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Feng YG; Yang H; Zhang Y; Huang XQ&#42;; Li LG; **Cheng T**; Shao Q&#42;;   
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Nano Lett. **2020**, 20, 8282–8289  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;[https://doi.org/10.1021/acs.nanolett.0c03400](https://doi.org/10.1021/acs.nanolett.0c03400)  
  
[74]&nbsp;&nbsp; <span style="color:blue;"> Bismuth Oxyhydroxide-Pt Inverse Interface for Enhanced Methanol Electrooxidation Performance  </span>  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Wang XC; Xie M; Lyu FL&#42;; Y YM; W ZQ; Chen JT; Chang LY; Xia YJ; Zhong QX; Chu MY; Yang H; **Cheng T&#42;**; Sham TK&#42;; Zhang Q&#42;;   
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Nano Lett. **2020**, 20, 7751–7759  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;[https://doi.org/10.1021/acs.nanolett.0c03340](https://doi.org/10.1021/acs.nanolett.0c03340)  
  
[73]&nbsp;&nbsp; <span style="color:blue;"> N-modulated Cu+ for efficient electrochemical carbon monoxide reduction to acetate  </span>  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Ni FL; Yang H; Wen YZ; Jiang ZH; Bai HP; Zhang LS; Cui CY; Wu LN; Li SY; He SS; **Cheng T&#42;**; Zhang B&#42;; Peng HS;   
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Sci. China Mater. **2020**, 63, 2606–2612  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;[https://doi.org/10.1007/s40843-020-1440-6](https://doi.org/10.1007/s40843-020-1440-6)  
  
[72]&nbsp;&nbsp; <span style="color:blue;"> Highly Selective Electrocatalytic Reduction of CO2 into Methane on Cu–Bi Nanoalloys  </span>  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Wang ZJ&#42;; Yuan Q; Shan JJ; Jiang ZH; Xu P; Hu YF; Zhou JG; Wu LN; Niu ZZ; Sun JM; **Cheng T&#42;**; Goddard WA&#42;;   
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;J. Phys. Chem. Lett. **2020**, 11, 7261–7266  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;[https://doi.org/10.1021/acs.jpclett.0c01261](https://doi.org/10.1021/acs.jpclett.0c01261)  
  
[71]&nbsp;&nbsp; <span style="color:blue;"> Highly Active and Stable Stepped Cu Surface for Enhanced Electrochemical CO2 Reduction to C2H4  </span>  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Choi C; Kwon S; **Cheng T**; Xu MJ; Tieu P; Cai J; Lee HM; Pan XQ; Duan XF; Goddard WA&#42;; Huang Y&#42;;   
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Nat. Catal. **2020**, 3, 804–812  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;[https://doi.org/10.1038/s41929-020-00504-x](https://doi.org/10.1038/s41929-020-00504-x)  
  
[70]&nbsp;&nbsp; <span style="color:blue;"> Surface engineering of RhOOH nanosheets promotes hydrogen evolution in alkaline  </span>  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Bai SX; Xie Miao; **Cheng T&#42;**; Cao KL; Xu Y&#42;; Huang XQ&#42;;   
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Nano Energy **2020**, 78, 105224  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;[https://doi.org/10.1016/j.nanoen.2020.105224](https://doi.org/10.1016/j.nanoen.2020.105224)  
  
[69]&nbsp;&nbsp; <span style="color:blue;"> Controllable CO adsorption determines ethylene and methane productions from CO2 electroreduction  </span>  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Bai HP; **Cheng T**; Li SY; Zhou ZY; Yang H; Li J; Xie M; Ye JY; Ji YJ; Li YY; Zhou ZY; Sun SG; Zhang Bo&#42;; Peng HS&#42;;   
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Sci. Bull **2020**, 78, 105224  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;[https://doi.org/10.1016/j.scib.2020.06.023](https://doi.org/10.1016/j.scib.2020.06.023)  
  
[68]&nbsp;&nbsp; <span style="color:blue;"> Synergy between Silver-Copper Surface Alloy Composition and Carbon Dioxide Adsorption and Activation  </span>  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Ye YF; Qian J; Yang H; Su HY; Lee KJ; Etxebarria A; **Cheng T**; Xiao H; Yano J&#42;; Goddard WA&#42;; Crumlin EJ&#42;;   
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;ACS Appl. Mater. Interfaces **2020**, 12, 25374–25382  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;[https://doi.org/10.1021/acsami.0c02057](https://doi.org/10.1021/acsami.0c02057)  
  
[67]&nbsp;&nbsp; <span style="color:blue;"> Atomistic Explanation of the Dramatically Improved Oxygen Reduction Reaction of Jagged Platinum Nanowires, 50 times better than Pt  </span>  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Chen YL; **Cheng T**; Goddard WA&#42;;   
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;J. Am. Chem. Soc. **2020**, 142, 8625  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;[https://doi.org/10.1021/jacs.9b13218](https://doi.org/10.1021/jacs.9b13218)  
  
[66]&nbsp;&nbsp; <span style="color:blue;"> A yolk–shell structured metal–organic framework with encapsulated iron-porphyrin and its derived bimetallic nitrogen-doped porous carbon for an efficient oxygen reduction reaction  </span>  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Zhang CC; Yang H; Zhong D; Xu Y; Wang YZ; Yuan Q; Liang ZZ; Wang B; Zhang Wei; Zheng HQ&#42;; **Cheng T&#42;**; Cao R&#42;;   
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;J. Mater. Chem. A, **2020**, 8, 9536  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;[https://doi.org/10.1039/D0TA00962H](https://doi.org/10.1039/D0TA00962H)  
  
[65]&nbsp;&nbsp; <span style="color:blue;"> tert-Butyl substituted hetero-donor TADF compounds for efficient solution-processed non-doped blue OLEDs  </span>  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Xie FM; An ZD; Xie M; Li YQ&#42;; Zhang GH; Zou SJ; Chen Li; Chen JD; **Cheng T&#42;**; Tang JX&#42;;   
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;J. Mater. Chem. C, **2020**, 8, 5769  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;[https://doi.org/10.1039/D0TC00718H](https://doi.org/10.1039/D0TC00718H)  
  
[64]&nbsp;&nbsp; <span style="color:blue;"> Customizable Ligand Exchange for Tailored Surface Property of Noble Metal Nanocrystals  </span>  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Fan QK; Yang H; Ge J; Zhang SM; Liu ZJ; Lei B; **Cheng T**; Li YY; Yin YD; Gao CB&#42;;   
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Research **2020**, 2131806  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;[https://doi.org/10.34133/2020/2131806](https://doi.org/10.34133/2020/2131806)  
  
[63]&nbsp;&nbsp; <span style="color:blue;"> High-Performance Nondoped Blue Delayed Fluorescence Organic Light-Emitting Diodes Featuring Low Driving Voltage and High Brightness  </span>  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Zou SJ; Xie FM; Xie M; Li YQ&#42;; **Cheng T**; Zhang XH; Lee CS&#42;; Tang JX&#42;;   
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Adv. Sci. **2020**, 7, 1902508  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;[https://doi.org/10.1002/advs.201902508](https://doi.org/10.1002/advs.201902508)  
  
[62]&nbsp;&nbsp; <span style="color:blue;"> Efficient Orange–Red Delayed Fluorescence Organic Light‐Emitting Diodes with External Quantum Efficiency over 26%  </span>  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Xie FM; Wu P; Zou SJ; Li YQ; **Cheng T**; Xie M; Tang JX&#42;; Zhao X&#42;;   
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Adv. Electron. Mater. **2020**, 6, 1900843  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;[https://doi.org/10.1002/aelm.201900843](https://doi.org/10.1002/aelm.201900843)  
  
[61]&nbsp;&nbsp; <span style="color:blue;"> Design of a One-Dimensional Stacked Spin Peierls System with Room Temperature Switching from QM Predictions  </span>  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Yang H; **Cheng T&#42;**; Goddard WA&#42;; Ren XM&#42;;   
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;J. Phys. Chem. Lett. **2019**, 10, 6432  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;[https://doi.org/10.1021/acs.jpclett.9b02219](https://doi.org/10.1021/acs.jpclett.9b02219)  
  
[60]&nbsp;&nbsp; <span style="color:blue;"> Weakening Hydrogen Adsorption on Nickel via Interstitial Nitrogen Doping Promotes Bifunctional Hydrogen Electrocatalysis in Alkaline Solution  </span>  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Wang TT; Wang M; Yang H; Xu MQ; Zuo GD; Feng K; Xie M; Deng J; Zhong J; Zhou W; **Cheng T&#42;**; Li YG&#42;;   
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Energy Environ. Sci. **2019**, 12, 3522  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;[https://doi.org/10.1039/C9EE01743G](https://doi.org/10.1039/C9EE01743G)  
  
[59]&nbsp;&nbsp; <span style="color:blue;"> Rational Molecular Design of Dibenzo[a,c]phenazine-based Thermally Activated Delayed Fluorescence Emitters for Orange-Red OLEDs with EQE up to 22.0%  </span>  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Xie FM; Li HZ; Dai GL; Li YQ; **Cheng T**; Xie M; Tang JX&#42;; Zhao X&#42;;   
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;ACS Appl. Mater. Interfaces **2019**, 11, 26144-26151  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;[https://doi.org/10.1021/acsami.9b06401](https://doi.org/10.1021/acsami.9b06401)  
  
[58]&nbsp;&nbsp; <span style="color:blue;"> Identifying Active Sites for CO2 Reduction on Dealloyed Gold Surfaces by Combining Machine Learning with Multiscale Simulations  </span>  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Chen YL; Huang YF; **Cheng T**; Goddard WA&#42;;   
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;J. Am. Chem. Soc. **2019**, 141, 11651-11657  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;[https://doi.org/10.1021/jacs.9b04956](https://doi.org/10.1021/jacs.9b04956)  
  
[57]&nbsp;&nbsp; <span style="color:blue;"> Formation of Carbon-Nitrogen Bonds in Carbon Monoxide Electrolysis  </span>  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Jouny M; Lv JJ; **Cheng T**; Ko BH; Zhu JJ; Goddard WA&#42;; Jiao F&#42;;   
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Nat. Chem. **2019**, 11, 846-851  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;[https://doi.org/10.1038/s41557-019-0312-z](https://doi.org/10.1038/s41557-019-0312-z)  
  
[56]&nbsp;&nbsp; <span style="color:blue;"> Benzo-Fused Periacenes or Double Helicenes? Different Cy-clodehydrogenation Pathways on Surface and in Solution  </span>  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Zhong QG; Hu YB; Niu KF; Zhang HM; Biao Y; Daniel E; Jalmar T; **Cheng T**; Andre S; Akimitsu N&#42;; Klaus M&#42;; Chi LF&#42;;   
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;J. Am. Chem. Soc. **2019**, 141, 7399-7406  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;[https://doi.org/10.1021/jacs.9b01267](https://doi.org/10.1021/jacs.9b01267)  
  
[55]&nbsp;&nbsp; <span style="color:blue;"> Single Atom Tailoring Platinum Nanocatalysts for High Performance Multifunctional Electrocatalysis  </span>  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Li MF; Duanmu KN; Wan CZ; **Cheng T**; Zhang L; Dai S; Chen WX; Zhao ZP; Li P; Fei HL; Zhu YM; Yu R; Luo J; Zang KT; Lin ZY; Ding MN; Huang J; Sun HT; Pan XQ; Guo JH; Goddard WA; Sautet P&#42;; Huang Y&#42;; Duan XF&#42;;   
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Nat. Catal. **2019**, 2, 495–503  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;[https://doi.org/10.1038/s41929-019-0279-6](https://doi.org/10.1038/s41929-019-0279-6)  
  
[54]&nbsp;&nbsp; <span style="color:blue;"> Electrocatalysis at Organic-Metal Interfaces: Identification of Structure-Reactivity Relationships for CO2 Reduction at Modified Cu Surfaces  </span>  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Buckley AK; Lee M; **Cheng T**; Kazantsev RV; Larson DM; Goddard WA; Tostel FD&#42;; Toma FM&#42;;   
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;J. Am. Chem. Soc **2019**, 141, 7355–7364  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;[https://doi.org/10.1021/jacs.8b13655](https://doi.org/10.1021/jacs.8b13655)  
  
[53]&nbsp;&nbsp; <span style="color:blue;"> Dramatic Differences in Carbon Dioxide Adsorption and Initial Steps of Reduction Between Silver and Copper  </span>  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Ye YF; Yang H; Qian J; Su HY; Lee KJ; **Cheng T**; Xiao H; Yano J&#42;; Goddard WA&#42;; Crumlin EJ&#42;;   
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Nat. Commun. **2019**, 10, 1875  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;[https://doi.org/10.1038/s41467-019-09846-y](https://doi.org/10.1038/s41467-019-09846-y)  
  
[52]&nbsp;&nbsp; <span style="color:blue;"> Reaction Intermediates During Operando Electrocatalysis Identiﬁed from Full Solvent Quantum Mechanics Molecular Dynamics  </span>  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;**Cheng T**; Fortunelli A; Goddard WA&#42;;   
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Proc. Natl. Acad. Sci. U.S.A. **2019**, 116, 7718-7722  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;[https://doi.org/10.1073/pnas.1821709116](https://doi.org/10.1073/pnas.1821709116)  
  
[51]&nbsp;&nbsp; <span style="color:blue;"> Discrete Dimers of Redox-Active and Fluorescent Perylene Diimide-Based Rigid Isosceles Triangles in the Solid State  </span>  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Nalluri SKM; Zhou JW; **Cheng T**; Liu ZC; Nguyen MT; Chen TY; Patel HA; Krzyaniak MD; Goddard WA; Wasielewski MR&#42;; Stoddart JF&#42;;   
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;J. Am. Chem. Soc. **2018**, 141, 1290–1303  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;[https://doi.org/10.1021/jacs.8b11201](https://doi.org/10.1021/jacs.8b11201)  
  
[50]&nbsp;&nbsp; <span style="color:blue;"> Highly Active Star Decahedron Cu Nanocatalyst for Hydrocarbon Production at Low Overpotentials  </span>  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Choi C; **Cheng T**; Expinosa MF; Fei HL; Duan XF; Goddard WA; Huang Y&#42;;   
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Adv. Mater. **2019**, 31, 1805405  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;[https://doi.org/10.1002/adma.201805405](https://doi.org/10.1002/adma.201805405)  
  
[49]&nbsp;&nbsp; <span style="color:blue;"> Identification of the Selective Sites for Electrochemical Reduction of CO to C2+ Products on Copper Nanoparticles by Combining Reactive Force Fields, Density Functional Theory, and Machine Learning  </span>  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Huang YF; Chen YL; **Cheng T**; Goddard WA&#42;;   
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;ACS Energy Lett. **2018**, 3, 2983–2988  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;[https://doi.org/10.1021/acsenergylett.8b01933](https://doi.org/10.1021/acsenergylett.8b01933)  
  
[48]&nbsp;&nbsp; <span style="color:blue;"> Molecular Russian Dolls  </span>  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Cai K; Lipke MC; Liu ZC; Nelson J; Shi Y; **Cheng T**; Cheng CY; Shen DK; Han JM; Vemuri S; Feng YN; Stern CL; Goddard WA; Wasielewski MR; Stoddart JF&#42;;   
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Nat. Commun. **2018**, 9, 5275  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;[https://doi.org/10.1038/s41467-018-07673-1](https://doi.org/10.1038/s41467-018-07673-1)  
  
[47]&nbsp;&nbsp; <span style="color:blue;"> The Neighboring Component Effect in a Tristable [2]Rotaxane  </span>  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Wang YP; **Cheng T**; Sun JL; Liu ZC; Frasconi M; Goddard WA; Stoddart JF&#42;;   
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;J. Am. Chem. Soc. **2018**, 140, 13827–13834  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;[https://doi.org/10.1021/jacs.8b08519](https://doi.org/10.1021/jacs.8b08519)  
  
[46]&nbsp;&nbsp; <span style="color:blue;"> First Principles Based Reaction Kinetics from Reactive Molecular Dynamics Simulations: Application to Hydrogen Peroxide Decomposition  </span>  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Ilyin DV; Goddard WA&#42;; Oppenheim JJ; **Cheng T**;   
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Proc. Natl. Acad. Sci. U.S.A. **2019**, 116, 18202-18208  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;[https://doi.org/10.1073/pnas.1701383115](https://doi.org/10.1073/pnas.1701383115)  
  
[45]&nbsp;&nbsp; <span style="color:blue;"> In silico Optimization of Organic-inorganic Hybrid Perovskites for Photocatalytic Hydrogen Evolution Reaction in Acidic Solution   </span>  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Wang L; Goddard WA&#42;; **Cheng T**; Xiao H; Li YY&#42;;   
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;J. Phys. Chem. C **2018**, 122, 20918-20922  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;[https://doi.org/10.1021/acs.jpcc.8b07380](https://doi.org/10.1021/acs.jpcc.8b07380)  
  
[44]&nbsp;&nbsp; <span style="color:blue;"> Electrochemical CO Reduction Builds Solvent Water into Oxygenate Products  </span>  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Lum YW; **Cheng T**; Goddard WA&#42;; Ager JW&#42;;   
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;J. Am. Chem. Soc. **2018**, 140, 9337-9340  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;[https://doi.org/10.1021/jacs.8b03986](https://doi.org/10.1021/jacs.8b03986)  
  
[43]&nbsp;&nbsp; <span style="color:blue;"> First Principles Based Multiscale Atomistic Methods for Input into First Principles Non-equilibrium Transport Across Interfaces  </span>  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;**Cheng T**; Jaramillo-Botero A; An Q; Ilyin DV; Naserifar S; Goddard WA&#42;;   
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Proc. Natl. Acad. Sci. U.S.A. **2019**, 116, 18193-18201  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;[https://doi.org/10.1073/pnas.1800035115](https://doi.org/10.1073/pnas.1800035115)  
  
[42]&nbsp;&nbsp; <span style="color:blue;"> Explanation of Dramatic pH-Dependence of Hydrogen Binding on Noble Metal Electrode: Greatly Weakened Water Adsorption at High pH.  </span>  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;**Cheng T**; Wang L; Boris MV; Goddard WA&#42;;   
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;J. Am. Chem. Soc. **2018**, 140, 7787-7790  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;[http://dx.doi.org/10.1021/jacs.8b04006](http://dx.doi.org/10.1021/jacs.8b04006)  
  
[41]&nbsp;&nbsp; <span style="color:blue;"> Surface Ligand Promotion of Carbon Dioxide Reduction through Stabilizing Chemisorbed Reactive Intermediates  </span>  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Wang ZJ&#42;; Wu LN; Sun K; Chen T; Jiang ZH; **Cheng T***; Goddard WA&#42;;   
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;J. Phys. Chem. Lett. **2018**, 9, 3057-3061  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;[http://dx.doi.org/10.1021/acs.jpclett.8b00959](http://dx.doi.org/10.1021/acs.jpclett.8b00959)  
  
[40]&nbsp;&nbsp; <span style="color:blue;"> Ordered Three-fold Symmetric Graphene Oxide/Buckled Graphene/Graphene Heterostructures on MgO (111) by Carbon Molecular Beam Epitaxy  </span>  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Ladewig C; **Cheng T**; Randle MD; Bird J; Olanipekun O; Dowben PA; Kelber J&#42;; Goddard WA&#42;;   
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;J. Mater. Chem. C **2018**, 6, 4225-4233  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;[http://dx.doi.org/10.1039/C8TC00178B](http://dx.doi.org/10.1039/C8TC00178B)  
  
[39]&nbsp;&nbsp; <span style="color:blue;"> Reaction Mechanisms and Sensitivity for Silicon Nitrocarbamate and Related Systems from Quantum Mechanics Reaction Dynamics  </span>  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Zhou TT; **Cheng T**; Zybin SZ; Goddard WA&#42;; Huang FL;   
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;J. Mater. Chem. A **2018**, 6, 5082-5097  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;[http://dx.doi.org/10.1039/C7TA10998A](http://dx.doi.org/10.1039/C7TA10998A)  
  
[38]&nbsp;&nbsp; <span style="color:blue;"> Pb-activated Amine-assisted Photocatalytic Hydrogen Evolution Reaction on Organic-Inorganic Perovskites  </span>  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Wang L&#42;; Xiao H; **Cheng T**; Li YY&#42;; Goddard WA&#42;;   
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;J. Am. Chem. Soc. **2018**, 140, 1994–1997  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;[http://dx.doi.org/10.1021/jacs.7b12028](http://dx.doi.org/10.1021/jacs.7b12028)  
  
[37]&nbsp;&nbsp; <span style="color:blue;"> Predicted Detonation Properties at the Chapman-Jouguet State for Proposed Energetic Materials (MTO and MTO3N) from Combined ReaxFF and Quantum Mechanics Reactive Dynamics  </span>  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Zhou T; Zybin SV; Goddard WA&#42;; **Cheng T**; Naserifar S; Jaramillo-Botero A; Huang FL;   
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Phys. Chem. Chem. Phys. **2018**, 20, 3953-3969  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;[http://dx.doi.org/10.1039/C7CP07321F](http://dx.doi.org/10.1039/C7CP07321F)  
  
[36]&nbsp;&nbsp; <span style="color:blue;"> Bulk Properties of Amorphous Lithium Dendrites  </span>  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Aryanfar A&#42;; **Cheng T**; Goddard WA;   
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;ECS Trans. **2017**, 80, 365-370  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;[http://dx.doi.org/10.1149/08010.0365ecst](http://dx.doi.org/10.1149/08010.0365ecst)  
  
[35]&nbsp;&nbsp; <span style="color:blue;"> Ultrahigh Mass Activity for Carbon Dioxide Reduction Enabled by Gold-iron Core-shell Nanoparticles  </span>  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Sun K; **Cheng T**; Wu LN; Hu YF; Zhou JG; Maclennan A; Jiang ZH; Gao YZ; Goddard WA&#42;; Wang ZJ&#42;;   
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;J. Am. Chem. Soc. **2017**, 139, 15608–15611  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;[http://dx.doi.org/10.1021/jacs.7b09251](http://dx.doi.org/10.1021/jacs.7b09251)  
  
[34]&nbsp;&nbsp; <span style="color:blue;"> Nature of the Active Sites for CO Reduction on Copper Nanoparticles; Suggestions for Optimizing Performance  </span>  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;**Cheng T**; Xiao H; Goddard WA&#42;;   
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;J. Am. Chem. Soc. **2017**, 139, 11642-11645  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;[http://dx.doi.org/10.1021/jacs.7b03300](http://dx.doi.org/10.1021/jacs.7b03300)  
  
[33]&nbsp;&nbsp; <span style="color:blue;"> Predicted Structures of the Active Sites Responsible for the Improved Reduction of Carbon Dioxide by Gold Nanoparticles  </span>  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;**Cheng T**; Huang YF; Xiao H; Goddard WA&#42;;   
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;J. Phys. Chem. Lett. **2017**, 8, 3317-3320  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;[http://dx.doi.org/10.1021/acs.jpclett.7b01335](http://dx.doi.org/10.1021/acs.jpclett.7b01335)  
  
[32]&nbsp;&nbsp; <span style="color:blue;"> Quantum Mechanics Reactive Dynamics Study of Solid Li-Electrode/Li6PS5Cl-Electrolyte Interface  </span>  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;**Cheng T**; Merinov BV&#42;; Morozov S; Goddard WA;   
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;ACS Energy Lett. **2017**, 2, 1454-1459  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;[http://dx.doi.org/10.1021/acsenergylett.7b00319](http://dx.doi.org/10.1021/acsenergylett.7b00319)  
  
[31]&nbsp;&nbsp; <span style="color:blue;"> Reactive Molecular Dynamics Simulations to Understand Mechanical Response of Thaumasite under Temperature and Strain Rate Effects  </span>  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Hajilar S; Shafei B&#42;; **Cheng T**; Jaramillo-Botero A;   
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;J. Phys. Chem. A **2017**, 121, 4688-4697  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;[http://dx.doi.org/10.1021/acs.jpca.7b02824](http://dx.doi.org/10.1021/acs.jpca.7b02824)  
  
[30]&nbsp;&nbsp; <span style="color:blue;"> Epitaxial Growth of Cobalt Oxide Phases on Ru(0001) for Spintronic Device Applications  </span>  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Olanipekun O; Ladewig C; Kelber J&#42;; Randle MD; Nathawat J; Kwan CP; Bird JP; Chakraborti P; Dowben PA; **Cheng T**; Goddard WA;   
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Semicond. Sci. Technol. **2017**, 32, 095011  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;[https://doi.org/10.1088/1361-6641/aa7c58](https://doi.org/10.1088/1361-6641/aa7c58)  
  
[29]&nbsp;&nbsp; <span style="color:blue;"> The Cu Metal Embedded in Oxidized Matrix Catalyst to Promote CO2 Activation and CO Dimerization for Efficient and Selective Electrochemical Reduction of CO2  </span>  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Xiao H; Goddard WA&#42;; **Cheng T**; Liu YY;   
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Proc. Natl. Acad. Sci. U.S.A. **2017**, 114, 6685-6688  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;[http://dx.doi.org/10.1073/pnas.1702405114](http://dx.doi.org/10.1073/pnas.1702405114)  
  
[28]&nbsp;&nbsp; <span style="color:blue;"> Subsurface Oxide Plays a Critical Role in CO2 Activation by Copper (111) Surfaces to Form  Chemisorbed CO2, the First Step in Reduction of CO2  </span>  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Favaro M; Xiao H; **Cheng T**; Goddard WA&#42;; Yano J&#42;; Crumlin EJ&#42;;   
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Proc. Natl. Acad. Sci. U.S.A. **2017**, 114, 6706-6711  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;[http://dx.doi.org/10.1073/pnas.1701405114](http://dx.doi.org/10.1073/pnas.1701405114)  
  
[27]&nbsp;&nbsp; <span style="color:blue;"> Intramolecular Energy and Electron Transfer Within a Diazaperopyrenium-Based Cyclophane  </span>  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Gong XR; Young RM; Hartlieb KJ; Miller C; Wu YL; Xiao H; Li P; Hafezi N; Zhou JW; Ma L; **Cheng T**; Goddard WA; Farha OK; Hupp JT; Wasielewski MR&#42;; Stoddart JF&#42;;   
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;J. Am. Chem. Soc. **2017**, 139, 4107-4116  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;[http://dx.doi.org/10.1021/jacs.6b13223](http://dx.doi.org/10.1021/jacs.6b13223)  
  
[26]&nbsp;&nbsp; <span style="color:blue;"> Size-Matched Radical Multivalency  </span>  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Lipke MC; **Cheng T**; Wu YL; Arslan H; Xiao H; Wasielewski MR; Goddard WA; Stoddart JF&#42;;   
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;J. Am. Chem. Soc. **2017**, 139, 3986-3998  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;[http://dx.doi.org/10.1021/jacs.6b09892](http://dx.doi.org/10.1021/jacs.6b09892)  
  
[25]&nbsp;&nbsp; <span style="color:blue;"> Full Atomistic Reaction Mechanism with Kinetics for CO Reduction on Cu(100) from ab initio Molecular Dynamics Free-energy Calculations at 298 K.  </span>  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;**Cheng T**; Xiao H; Goddard WA&#42;;   
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Proc. Natl. Acad. Sci. U.S.A. **2017**, 114, 1795-1800  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;[http://dx.doi.org/10.1073/pnas.1612106114](http://dx.doi.org/10.1073/pnas.1612106114)  
  
[24]&nbsp;&nbsp; <span style="color:blue;"> Mechanism and Kinetics of the Electrocatalytic Reaction Responsible for the High Cost of Hydrogen Fuel Cells  </span>  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;**Cheng T**; Goddard WA&#42;; An Q; Xiao H; Merinov B; Morozov S;   
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Phys. Chem. Chem. Phys. **2017**, 19, 2666-2673  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;[http://dx.doi.org/10.1039/C6CP08055C](http://dx.doi.org/10.1039/C6CP08055C)  
  
[23]&nbsp;&nbsp; <span style="color:blue;"> Atomistic Mechanisms Underlying Selectivities in C1 and C2 Products from Electrochemical Reduction of CO on Cu(111)  </span>  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Xiao H; **Cheng T**; Goddard WA&#42;;   
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;J. Am. Chem. Soc. **2017**, 139, 130-136  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;[http://dx.doi.org/10.1021/jacs.6b06846](http://dx.doi.org/10.1021/jacs.6b06846)  
  
[22]&nbsp;&nbsp; <span style="color:blue;"> Nucleation of Graphene Layers On Magnetic Oxides: Co3O4 (111) and Cr2O3 (0001) from Theory and Experiment  </span>  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Beatty J; **Cheng T**; Cao Y; Driver M; Goddard WA&#42;; Kelber J&#42;;   
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;J. Phys. Chem. Lett. **2017**, 8, 188-192  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;[http://dx.doi.org/10.1021/acs.jpclett.6b02325](http://dx.doi.org/10.1021/acs.jpclett.6b02325)  
  
[21]&nbsp;&nbsp; <span style="color:blue;"> Ultrafine Jagged Platinum Nanowires Enable Ultrahigh Mass Activity for the Oxygen Reduction Reaction  </span>  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Li MF; Zhao ZP; **Cheng T**; Fortunelli A; Chen CY; Yu R; Zhang QH; Gu L; Merinov B; Lin ZY; Zhu EB; Yu T; Jia QY; Guo JH; Zhang L; Goddard WA&#42;; Huang Y&#42;; Duan XF&#42;;   
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Science **2016**, 354, 1414-1419  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;[http://dx.doi.org/10.1126/science.aaf9050](http://dx.doi.org/10.1126/science.aaf9050)  
  
[20]&nbsp;&nbsp; <span style="color:blue;"> Reaction Mechanisms for the Electrochemical Reduction of CO2 to CO and Formate on the Cu(100) Surface at 298 K from Quantum Mechanics Free Energy Calculations with Explicit Water  </span>  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;**Cheng T**; Xiao H; Goddard WA&#42;;   
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;J. Am. Chem. Soc. **2016**, 138, 13802-13805  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;[http://dx.doi.org/10.1021/jacs.6b08534](http://dx.doi.org/10.1021/jacs.6b08534)  
  
[19]&nbsp;&nbsp; <span style="color:blue;"> Influence of Constitution and Charge on Radical Pairing Interactions in Trisradical Tricationic Complexes  </span>  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Cheng CY; **Cheng T**; Xiao H; Krzyaniak MD; Wang YP; McGonigal PR; Frasconi M; Barnes JC; Fahrenbach AC; Wasielewski MR; Goddard WA; Stoddart JF&#42;;   
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;J. Am. Chem. Soc. **2016**, 138, 8288-8300  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;[http://dx.doi.org/10.1021/jacs.6b04343](http://dx.doi.org/10.1021/jacs.6b04343)  
  
[18]&nbsp;&nbsp; <span style="color:blue;"> Mechanistic Explanation of the pH Dependence and Onset Potentials for Hydrocarbon Products from Electrochemical Reduction of CO on Cu(111)  </span>  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Xiao H; **Cheng T**; Goddard WA&#42;; Sundararaman R;   
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;J. Am. Chem. Soc. **2016**, 138, 483-486  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;[http://dx.doi.org/10.1021/jacs.5b11390](http://dx.doi.org/10.1021/jacs.5b11390)  
  
[17]&nbsp;&nbsp; <span style="color:blue;"> Free-Energy Barriers and Reaction Mechanisms for the Electrochemical Reduction of CO on the Cu(100) Surface, Including Multiple Layers of Explicit Solvent at pH 0  </span>  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;**Cheng T**; Xiao H; Goddard WA&#42;;   
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;J. Phys. Chem. Lett. **2015**, 6, 4767-4773  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;[http://dx.doi.org/10.1021/acs.jpclett.5b02247](http://dx.doi.org/10.1021/acs.jpclett.5b02247)  
  
[16]&nbsp;&nbsp; <span style="color:blue;"> Annealing Kinetics of Electrodeposited Lithium Dendrites  </span>  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Aryanfar A&#42;; **Cheng T**; Colussi AJ; Goddard WA; Hoffmann MR;   
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;J. Chem. Phys. **2015**, 143, 134701  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;[http://dx.doi.org/10.1063/1.4930014](http://dx.doi.org/10.1063/1.4930014)  
  
[15]&nbsp;&nbsp; <span style="color:blue;"> Rescaling of Metal Oxide Nanocrystals for Energy Storage Having High Capacitance and Energy Density with Robust Cycle Life  </span>  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Jeong HM; Choi KM; **Cheng T**; Lee DK; Zhou RJ; Ock IW; Milliron DJ; Colussi AJ; Goddard WA&#42;; Kang JK&#42;;   
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Proc. Natl. Acad. Sci. U.S.A. **2015**, 112, 7914-7919  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;[http://dx.doi.org/10.1073/pnas.1503546112](http://dx.doi.org/10.1073/pnas.1503546112)  
  
[14]&nbsp;&nbsp; <span style="color:blue;"> Initial Decomposition Reactions of Bicyclo-HMX [BCHMX or cis-1,3,4,6 Tetranitrooctahydroimidazo-[4,5-d]imidazole] from Quantum Molecular Dynamics Simulations  </span>  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Ye CC; An Q; Goddard WA&#42;; **Cheng T**; Zybin ZV; Ju XH;   
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;J. Phys. Chem. C **2015**, 119, 2290-2296  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;[http://dx.doi.org/10.1021/jp510328d](http://dx.doi.org/10.1021/jp510328d)  
  
[13]&nbsp;&nbsp; <span style="color:blue;"> Anisotropic Impact Sensitivity and Shock Induced Plasticity of TKX-50 (Dihydroxylammonium 5,5-bis(tetrazole)-1,1-diolate) Single Crystals: From Large-Scale Molecular Dynamics Simulations  </span>  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;An Q; **Cheng T**; Goddard WA&#42;; Zybin ZV;   
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;J. Phys. Chem. C **2015**, 119, 2196-2207  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;[http://dx.doi.org/10.1021/jp510951s](http://dx.doi.org/10.1021/jp510951s)  
  
[12]&nbsp;&nbsp; <span style="color:blue;"> Reaction Mechanism from Quantum Molecular Dynamics for the Initial Thermal Decomposition of 2, 4, 6-triamino-1, 3, 5-triazine-1, 3, 5-trioxide (MTO) and 2, 4, 6-trinitro-1, 3, 5-triazine-1, 3, 5-trioxide (MTO3N), Promising Green Energetic Materials  </span>  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Ye CC; An Q; **Cheng T**; Zybin ZV; Naserifar S; Goddard WA&#42;;   
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;J. Mater. Chem. A **2015**, 3, 12044-12050  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;[http://dx.doi.org/10.1039/C5TA02486B](http://dx.doi.org/10.1039/C5TA02486B)  
  
[11]&nbsp;&nbsp; <span style="color:blue;"> Initial Decomposition Reaction of Di-tetrazine-tetroxide (Dtto) from Quantum Molecular Dynamics: Implications for a Promising Energetic Material  </span>  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Ye CC; An Q; Goddard WA&#42;; **Cheng T**; Liu WG; Zybin ZV; Ju XH;   
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;J. Mater. Chem. A **2015**, 3, 1972-1978  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;[http://dx.doi.org/10.1039/C4TA05676K](http://dx.doi.org/10.1039/C4TA05676K)  
  
[10]&nbsp;&nbsp; <span style="color:blue;"> Initial Steps of Thermal Decomposition of Dihydroxylammonium 5,5 -bistetrazole-1,1 -diolate Crystals from Quantum Mechanics  </span>  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;An Q; Liu WG; Goddard WA&#42;; **Cheng T**; Zybin ZV; Xiao H;   
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;J Phys. Chem. C **2014**, 118, 27175-27181  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;[http://dx.doi.org/10.1021/jp509582x](http://dx.doi.org/10.1021/jp509582x)  
  
[9]&nbsp;&nbsp; <span style="color:blue;"> Atomistic Explanation of Shear-Induced Amorphous Band Formation in Boron Carbide  </span>  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;An Q; Goddard WA&#42;; **Cheng T**;   
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Phys. Rev. Lett. **2014**, 113, 095501  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;[http://dx.doi.org/10.1103/PhysRevLett.113.095501](http://dx.doi.org/10.1103/PhysRevLett.113.095501)  
  
[8]&nbsp;&nbsp; <span style="color:blue;"> Deformation Induced Solid/Solid Phase Transitions in Gamma Boron  </span>  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;An Q; Goddard WA&#42;; Xiao H; **Cheng T**;   
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Chem. Mater. **2014**, 26, 4289-4298  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;[http://dx.doi.org/10.1021/cm5020114](http://dx.doi.org/10.1021/cm5020114)  
  
[7]&nbsp;&nbsp; <span style="color:blue;"> Adaptive Accelerated ReaxFF Reactive Dynamics with Validation from Simulating Hydrogen Combustion  </span>  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;**Cheng T**; Goddard WA&#42;; Goddard WA&#42;; Jaramillo-Botero A&#42;; Sun H&#42;;   
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;J. Am. Chem. Soc. **2014**, 136, 9434-9442  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;[http://dx.doi.org/10.1021/ja5037258](http://dx.doi.org/10.1021/ja5037258)  
  
[6]&nbsp;&nbsp; <span style="color:blue;"> Adsorption of Ethanol Vapor on Mica Surface under Different Relative Humidities: A Molecular Simulation Study  </span>  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;**Cheng T**; Sun H&#42;;   
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;J. Phys. Chem. C **2012**, 116, 16436-16446  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;[http://dx.doi.org/10.1021/jp3020595](http://dx.doi.org/10.1021/jp3020595)  
  
[5]&nbsp;&nbsp; <span style="color:blue;"> Prediction of the Mutual Solubility of Water and Dipropylene Glycol Dimethyl Ether Using Molecular Dynamics Simulation  </span>  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;**Cheng T**; Li F; Dai JX; Sun H&#42;;   
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Fluid Phase Equilibria. **2012**, 314, 1-6  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;[http://dx.doi.org/10.1016/j.fluid.2011.10.013](http://dx.doi.org/10.1016/j.fluid.2011.10.013)  
  
[4]&nbsp;&nbsp; <span style="color:blue;"> Molecular Engineering of Microporous Crystals: (Iv) Crystallization Process of Microporous Aluminophosphate Alpo4-11  </span>  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;**Cheng T**; Xu J; Li X; Zhang B; Yan WF&#42;; Yu JH; Sun H; Deng F; Xu RR&#42;;   
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Micropor. Mesopor. Mater. **2012**, 152, 190-207  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;[http://dx.doi.org/10.1016/j.micromeso.2011.11.034](http://dx.doi.org/10.1016/j.micromeso.2011.11.034)  
  
[3]&nbsp;&nbsp; <span style="color:blue;"> Classic Force Field for Predicting Surface Tension and Interfacial Properties of Sodium Dodecyl Sulfate  </span>  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;**Cheng T**; Chen Q; Li F; Sun H&#42;;   
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;J. Phys. Chem. B **2010**, 114, 13736-13744  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;[http://dx.doi.org/10.1021/jp107002x](http://dx.doi.org/10.1021/jp107002x)  
  
[2]&nbsp;&nbsp; <span style="color:blue;"> On the Accuracy of Predicting Shear Viscosity of Molecular Liquids Using the Periodic Perturbation Method  </span>  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Zhao LF; **Cheng T**; Sun H&#42;;   
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;J. Chem. Phys. **2008**, 129, 144501  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;[http://dx.doi.org/10.1063/1.2936986](http://dx.doi.org/10.1063/1.2936986)  
  
[1]&nbsp;&nbsp; <span style="color:blue;"> One Force Field for Predicting Multiple Thermodynamic Properties of Liquid and Vapor Ethylene Oxide  </span>  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Li XF; Zhao LF; Cheng T; Liu LC; Sun H&#42;;   
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Fluid Phase Equilib. **2008**, 274, 36-43  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;[http://dx.doi.org/10.1016/j.fluid.2008.06.021](http://dx.doi.org/10.1016/j.fluid.2008.06.021)  
  
