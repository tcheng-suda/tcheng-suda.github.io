import os
import yaml  # or import json

fname = '/Users/tao/Desktop/wf/publications.md'
html_fname = '/Users/tao/Desktop/wf/publications.html'

def parse_file(fname):
    with open(fname, 'r') as file:
        # If the file is JSON, use: data = json.load(file)
        # For YAML or similar formats, use:
        jid = fname.split('.')[0]
        data = yaml.safe_load(file)
        return jid, data

def test():
    jid, data = parse_file('0191.txt')
    print(jid, data)

def main():
    papers = []
    for i in os.listdir('.'):
        if i.endswith('.txt'):
            papers.append(i)

    items = []
    papers.sort(reverse=True)
    for n, i in enumerate(papers):
        jid, data = parse_file(i)
        items.append([jid, data])
        
    o = open(fname, 'w')
    for n, i in enumerate(items):
        # write the tile
        if int(i[0]) < 100:
            o.write('[%d]&nbsp;&nbsp; <span style="color:blue;"> %s  </span>  \n'%(int(i[0]), i[1][0]['title']))
        else:
            o.write('[%d]&nbsp; <span style="color:blue;"> %s  </span>  \n'%(int(i[0]), i[1][0]['title']))
        # write the authors
        o.write(''.join(['&nbsp;']*10))
        line = ''
        for ii in i[1][0]['author']:
            name = ''
            name += '%s '%(ii['family'])
            name += '%s'%(ii['given_initial'])
            if 'role' in ii.keys():
                if 'main' in ii['role']:
                    if 'corr' in ii['role']:
                        name = ''
                        name += '**%s '%(ii['family'])
                        name += '%s&#42;**'%(ii['given_initial'])
                    else:
                        name = ''
                        name += '**%s '%(ii['family'])
                        name += '%s**'%(ii['given_initial'])
                else:
                    if 'corr' in ii['role']:
                        name += '&#42;'
            name += '; '
            line += name
        o.write(line)
        o.write('  \n')
        # write the journals and details
        o.write(''.join(['&nbsp;']*10))
        o.write('*%s*'%i[1][0]['journal']['abbreviation'])
        o.write(' **%s**'%i[1][0]['year'])
        if 'volume' in i[1][0].keys():
            if i[1][0]['volume']:
                o.write(', %s'%i[1][0]['volume'])
        if 'page' in i[1][0].keys():
            if i[1][0]['page']:
                o.write(', %s'%i[1][0]['page'])
        o.write('  \n')
        # write the URL
        o.write(''.join(['&nbsp;']*10))
        if 'URL' in i[1][0].keys():
            if i[1][0]['URL']:
                o.write('[%s](%s)'%(i[1][0]['URL'], i[1][0]['URL']))
                o.write('  \n')
        # end of the item
        o.write('  \n')
    o.close()
    os.system('pandoc -f markdown -t html5 -o %s %s'%(html_fname, fname))

main()
