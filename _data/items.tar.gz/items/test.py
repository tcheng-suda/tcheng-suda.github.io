# Read the extracted text from the file to parse it into HTML
with open(text_file_path, 'r') as file:
    extracted_text = file.readlines()

# Filter out empty lines and strip whitespace
extracted_text = [line.strip() for line in extracted_text if line.strip()]

# HTML parts
html_header = """
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Published Papers</title>
    <style>
        body { font-family: Arial, sans-serif; }
        .paper { margin-bottom: 20px; }
        .title { font-weight: bold; }
        .authors { margin-bottom: 5px; }
        .journal { font-style: italic; }
    </style>
</head>
<body>
    <h1>Published Papers</h1>
"""

html_footer = """
</body>
</html>
"""

# Parse the lines to create HTML content
html_content = ""
for line in extracted_text:
    # Assuming the first part is the title, followed by authors, and then the journal info
    parts = line.split(';')
    if len(parts) > 2:  # Check if the line contains enough parts to be a paper entry
        title = parts[0].strip()
        authors = parts[1].strip()
        journal_info = parts[2].strip()
        
        # Create the HTML block for this paper
        paper_html = f"""
        <div class="paper">
            <div class="title">{title}</div>
            <div class="authors">{authors}</div>
            <div class="journal">{journal_info}</div>
        </div>
        """
        html_content += paper_html

# Full HTML content
full_html = html_header + html_content + html_footer

# Write the HTML content to a new .html file
html_file_path = 'published_papers.html'
with open(html_file_path, 'w') as html_file:
    html_file.write(full_html)

html_file_path

